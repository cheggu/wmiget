﻿namespace Hardware
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp_select_hw = new System.Windows.Forms.GroupBox();
            this.btn_os = new System.Windows.Forms.Button();
            this.btn_bios = new System.Windows.Forms.Button();
            this.btn_monitor = new System.Windows.Forms.Button();
            this.btn_netadapt = new System.Windows.Forms.Button();
            this.btn_motherboard = new System.Windows.Forms.Button();
            this.btn_gpu = new System.Windows.Forms.Button();
            this.btn_sdd = new System.Windows.Forms.Button();
            this.btn_hdd = new System.Windows.Forms.Button();
            this.btn_ram = new System.Windows.Forms.Button();
            this.btn_cpu = new System.Windows.Forms.Button();
            this.grp_info = new System.Windows.Forms.GroupBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.lbl45 = new System.Windows.Forms.Label();
            this.lbl44 = new System.Windows.Forms.Label();
            this.lbl43 = new System.Windows.Forms.Label();
            this.lbl42 = new System.Windows.Forms.Label();
            this.lbl41 = new System.Windows.Forms.Label();
            this.lbl40 = new System.Windows.Forms.Label();
            this.lbl39 = new System.Windows.Forms.Label();
            this.lbl38 = new System.Windows.Forms.Label();
            this.lbl37 = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.btn_export = new System.Windows.Forms.Button();
            this.grp_export = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grp_select_hw.SuspendLayout();
            this.grp_info.SuspendLayout();
            this.grp_export.SuspendLayout();
            this.SuspendLayout();
            // 
            // grp_select_hw
            // 
            this.grp_select_hw.Controls.Add(this.btn_os);
            this.grp_select_hw.Controls.Add(this.btn_bios);
            this.grp_select_hw.Controls.Add(this.btn_monitor);
            this.grp_select_hw.Controls.Add(this.btn_netadapt);
            this.grp_select_hw.Controls.Add(this.btn_motherboard);
            this.grp_select_hw.Controls.Add(this.btn_gpu);
            this.grp_select_hw.Controls.Add(this.btn_sdd);
            this.grp_select_hw.Controls.Add(this.btn_hdd);
            this.grp_select_hw.Controls.Add(this.btn_ram);
            this.grp_select_hw.Controls.Add(this.btn_cpu);
            this.grp_select_hw.Location = new System.Drawing.Point(12, 12);
            this.grp_select_hw.Name = "grp_select_hw";
            this.grp_select_hw.Size = new System.Drawing.Size(1040, 57);
            this.grp_select_hw.TabIndex = 0;
            this.grp_select_hw.TabStop = false;
            this.grp_select_hw.Text = "System Components";
            // 
            // btn_os
            // 
            this.btn_os.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_os.Location = new System.Drawing.Point(956, 16);
            this.btn_os.Name = "btn_os";
            this.btn_os.Size = new System.Drawing.Size(78, 35);
            this.btn_os.TabIndex = 9;
            this.btn_os.Text = "OS";
            this.btn_os.UseVisualStyleBackColor = true;
            this.btn_os.Click += new System.EventHandler(this.btn_os_Click);
            // 
            // btn_bios
            // 
            this.btn_bios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bios.Location = new System.Drawing.Point(854, 16);
            this.btn_bios.Name = "btn_bios";
            this.btn_bios.Size = new System.Drawing.Size(96, 35);
            this.btn_bios.TabIndex = 8;
            this.btn_bios.Text = "BIOS";
            this.btn_bios.UseVisualStyleBackColor = true;
            this.btn_bios.Click += new System.EventHandler(this.btn_bios_Click);
            // 
            // btn_monitor
            // 
            this.btn_monitor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_monitor.Location = new System.Drawing.Point(752, 16);
            this.btn_monitor.Name = "btn_monitor";
            this.btn_monitor.Size = new System.Drawing.Size(96, 35);
            this.btn_monitor.TabIndex = 7;
            this.btn_monitor.Text = "Monitor(s)";
            this.btn_monitor.UseVisualStyleBackColor = true;
            this.btn_monitor.Click += new System.EventHandler(this.btn_monitor_Click);
            // 
            // btn_netadapt
            // 
            this.btn_netadapt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_netadapt.Location = new System.Drawing.Point(618, 16);
            this.btn_netadapt.Name = "btn_netadapt";
            this.btn_netadapt.Size = new System.Drawing.Size(128, 35);
            this.btn_netadapt.TabIndex = 6;
            this.btn_netadapt.Text = "Network Adapter";
            this.btn_netadapt.UseVisualStyleBackColor = true;
            this.btn_netadapt.Click += new System.EventHandler(this.btn_netadapt_Click);
            // 
            // btn_motherboard
            // 
            this.btn_motherboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_motherboard.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_motherboard.Location = new System.Drawing.Point(516, 16);
            this.btn_motherboard.Name = "btn_motherboard";
            this.btn_motherboard.Size = new System.Drawing.Size(96, 35);
            this.btn_motherboard.TabIndex = 5;
            this.btn_motherboard.Text = "Motherboard";
            this.btn_motherboard.UseVisualStyleBackColor = true;
            this.btn_motherboard.Click += new System.EventHandler(this.btn_motherboard_Click);
            // 
            // btn_gpu
            // 
            this.btn_gpu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_gpu.Location = new System.Drawing.Point(414, 16);
            this.btn_gpu.Name = "btn_gpu";
            this.btn_gpu.Size = new System.Drawing.Size(96, 35);
            this.btn_gpu.TabIndex = 4;
            this.btn_gpu.Text = "GPU(s)";
            this.btn_gpu.UseVisualStyleBackColor = true;
            this.btn_gpu.Click += new System.EventHandler(this.btn_gpu_Click);
            // 
            // btn_sdd
            // 
            this.btn_sdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sdd.Location = new System.Drawing.Point(312, 16);
            this.btn_sdd.Name = "btn_sdd";
            this.btn_sdd.Size = new System.Drawing.Size(96, 35);
            this.btn_sdd.TabIndex = 3;
            this.btn_sdd.Text = "SSD(s)";
            this.btn_sdd.UseVisualStyleBackColor = true;
            this.btn_sdd.Click += new System.EventHandler(this.btn_sdd_Click);
            // 
            // btn_hdd
            // 
            this.btn_hdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_hdd.Location = new System.Drawing.Point(210, 16);
            this.btn_hdd.Name = "btn_hdd";
            this.btn_hdd.Size = new System.Drawing.Size(96, 35);
            this.btn_hdd.TabIndex = 2;
            this.btn_hdd.Text = "HDD(s)";
            this.btn_hdd.UseVisualStyleBackColor = true;
            this.btn_hdd.Click += new System.EventHandler(this.btn_hdd_Click);
            // 
            // btn_ram
            // 
            this.btn_ram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ram.Location = new System.Drawing.Point(108, 16);
            this.btn_ram.Name = "btn_ram";
            this.btn_ram.Size = new System.Drawing.Size(96, 35);
            this.btn_ram.TabIndex = 1;
            this.btn_ram.Text = "Memory";
            this.btn_ram.UseVisualStyleBackColor = true;
            this.btn_ram.Click += new System.EventHandler(this.btn_ram_Click);
            // 
            // btn_cpu
            // 
            this.btn_cpu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cpu.Location = new System.Drawing.Point(6, 16);
            this.btn_cpu.Name = "btn_cpu";
            this.btn_cpu.Size = new System.Drawing.Size(96, 35);
            this.btn_cpu.TabIndex = 0;
            this.btn_cpu.Text = "CPU";
            this.btn_cpu.UseVisualStyleBackColor = true;
            this.btn_cpu.Click += new System.EventHandler(this.btn_cpu_Click);
            // 
            // grp_info
            // 
            this.grp_info.Controls.Add(this.textBox31);
            this.grp_info.Controls.Add(this.textBox32);
            this.grp_info.Controls.Add(this.textBox33);
            this.grp_info.Controls.Add(this.textBox34);
            this.grp_info.Controls.Add(this.textBox35);
            this.grp_info.Controls.Add(this.textBox36);
            this.grp_info.Controls.Add(this.textBox37);
            this.grp_info.Controls.Add(this.textBox38);
            this.grp_info.Controls.Add(this.textBox39);
            this.grp_info.Controls.Add(this.textBox40);
            this.grp_info.Controls.Add(this.textBox41);
            this.grp_info.Controls.Add(this.textBox42);
            this.grp_info.Controls.Add(this.textBox43);
            this.grp_info.Controls.Add(this.textBox44);
            this.grp_info.Controls.Add(this.textBox45);
            this.grp_info.Controls.Add(this.lbl45);
            this.grp_info.Controls.Add(this.lbl44);
            this.grp_info.Controls.Add(this.lbl43);
            this.grp_info.Controls.Add(this.lbl42);
            this.grp_info.Controls.Add(this.lbl41);
            this.grp_info.Controls.Add(this.lbl40);
            this.grp_info.Controls.Add(this.lbl39);
            this.grp_info.Controls.Add(this.lbl38);
            this.grp_info.Controls.Add(this.lbl37);
            this.grp_info.Controls.Add(this.lbl36);
            this.grp_info.Controls.Add(this.lbl35);
            this.grp_info.Controls.Add(this.lbl34);
            this.grp_info.Controls.Add(this.lbl33);
            this.grp_info.Controls.Add(this.lbl32);
            this.grp_info.Controls.Add(this.lbl31);
            this.grp_info.Controls.Add(this.textBox16);
            this.grp_info.Controls.Add(this.textBox17);
            this.grp_info.Controls.Add(this.textBox18);
            this.grp_info.Controls.Add(this.textBox19);
            this.grp_info.Controls.Add(this.textBox20);
            this.grp_info.Controls.Add(this.textBox21);
            this.grp_info.Controls.Add(this.textBox22);
            this.grp_info.Controls.Add(this.textBox23);
            this.grp_info.Controls.Add(this.textBox24);
            this.grp_info.Controls.Add(this.textBox25);
            this.grp_info.Controls.Add(this.textBox26);
            this.grp_info.Controls.Add(this.textBox27);
            this.grp_info.Controls.Add(this.textBox28);
            this.grp_info.Controls.Add(this.textBox29);
            this.grp_info.Controls.Add(this.textBox30);
            this.grp_info.Controls.Add(this.lbl30);
            this.grp_info.Controls.Add(this.lbl29);
            this.grp_info.Controls.Add(this.lbl28);
            this.grp_info.Controls.Add(this.lbl27);
            this.grp_info.Controls.Add(this.lbl26);
            this.grp_info.Controls.Add(this.lbl25);
            this.grp_info.Controls.Add(this.lbl24);
            this.grp_info.Controls.Add(this.lbl23);
            this.grp_info.Controls.Add(this.lbl22);
            this.grp_info.Controls.Add(this.lbl21);
            this.grp_info.Controls.Add(this.lbl20);
            this.grp_info.Controls.Add(this.lbl19);
            this.grp_info.Controls.Add(this.lbl18);
            this.grp_info.Controls.Add(this.lbl17);
            this.grp_info.Controls.Add(this.lbl16);
            this.grp_info.Controls.Add(this.textBox15);
            this.grp_info.Controls.Add(this.textBox14);
            this.grp_info.Controls.Add(this.textBox13);
            this.grp_info.Controls.Add(this.textBox12);
            this.grp_info.Controls.Add(this.textBox11);
            this.grp_info.Controls.Add(this.textBox10);
            this.grp_info.Controls.Add(this.textBox9);
            this.grp_info.Controls.Add(this.textBox8);
            this.grp_info.Controls.Add(this.textBox7);
            this.grp_info.Controls.Add(this.textBox6);
            this.grp_info.Controls.Add(this.textBox5);
            this.grp_info.Controls.Add(this.textBox4);
            this.grp_info.Controls.Add(this.textBox3);
            this.grp_info.Controls.Add(this.textBox2);
            this.grp_info.Controls.Add(this.textBox1);
            this.grp_info.Controls.Add(this.lbl15);
            this.grp_info.Controls.Add(this.lbl14);
            this.grp_info.Controls.Add(this.lbl13);
            this.grp_info.Controls.Add(this.lbl12);
            this.grp_info.Controls.Add(this.lbl11);
            this.grp_info.Controls.Add(this.lbl10);
            this.grp_info.Controls.Add(this.lbl9);
            this.grp_info.Controls.Add(this.lbl8);
            this.grp_info.Controls.Add(this.lbl7);
            this.grp_info.Controls.Add(this.lbl6);
            this.grp_info.Controls.Add(this.lbl5);
            this.grp_info.Controls.Add(this.lbl4);
            this.grp_info.Controls.Add(this.lbl3);
            this.grp_info.Controls.Add(this.lbl2);
            this.grp_info.Controls.Add(this.lbl1);
            this.grp_info.Location = new System.Drawing.Point(12, 75);
            this.grp_info.Name = "grp_info";
            this.grp_info.Size = new System.Drawing.Size(1494, 634);
            this.grp_info.TabIndex = 1;
            this.grp_info.TabStop = false;
            this.grp_info.Text = "System Information";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(698, 562);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(277, 25);
            this.textBox16.TabIndex = 59;
            this.textBox16.Visible = false;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(698, 524);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(277, 25);
            this.textBox17.TabIndex = 58;
            this.textBox17.Visible = false;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(698, 486);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(277, 25);
            this.textBox18.TabIndex = 57;
            this.textBox18.Visible = false;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(698, 448);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(277, 25);
            this.textBox19.TabIndex = 56;
            this.textBox19.Visible = false;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(698, 410);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(277, 25);
            this.textBox20.TabIndex = 55;
            this.textBox20.Visible = false;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(698, 372);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(277, 25);
            this.textBox21.TabIndex = 54;
            this.textBox21.Visible = false;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(698, 334);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(277, 25);
            this.textBox22.TabIndex = 53;
            this.textBox22.Visible = false;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(698, 296);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(277, 25);
            this.textBox23.TabIndex = 52;
            this.textBox23.Visible = false;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(698, 258);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(277, 25);
            this.textBox24.TabIndex = 51;
            this.textBox24.Visible = false;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(698, 220);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(277, 25);
            this.textBox25.TabIndex = 50;
            this.textBox25.Visible = false;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(698, 182);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(277, 25);
            this.textBox26.TabIndex = 49;
            this.textBox26.Visible = false;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(698, 147);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(277, 25);
            this.textBox27.TabIndex = 48;
            this.textBox27.Visible = false;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(698, 106);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(277, 25);
            this.textBox28.TabIndex = 47;
            this.textBox28.Visible = false;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(698, 68);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(277, 25);
            this.textBox29.TabIndex = 46;
            this.textBox29.Visible = false;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(698, 30);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(277, 25);
            this.textBox30.TabIndex = 45;
            this.textBox30.Visible = false;
            // 
            // lbl30
            // 
            this.lbl30.AutoSize = true;
            this.lbl30.Location = new System.Drawing.Point(514, 565);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(43, 17);
            this.lbl30.TabIndex = 44;
            this.lbl30.Text = "label1";
            this.lbl30.Visible = false;
            // 
            // lbl29
            // 
            this.lbl29.AutoSize = true;
            this.lbl29.Location = new System.Drawing.Point(514, 527);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(43, 17);
            this.lbl29.TabIndex = 43;
            this.lbl29.Text = "label1";
            this.lbl29.Visible = false;
            // 
            // lbl28
            // 
            this.lbl28.AutoSize = true;
            this.lbl28.Location = new System.Drawing.Point(514, 489);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(43, 17);
            this.lbl28.TabIndex = 42;
            this.lbl28.Text = "label1";
            this.lbl28.Visible = false;
            // 
            // lbl27
            // 
            this.lbl27.AutoSize = true;
            this.lbl27.Location = new System.Drawing.Point(514, 451);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(43, 17);
            this.lbl27.TabIndex = 41;
            this.lbl27.Text = "label1";
            this.lbl27.Visible = false;
            // 
            // lbl26
            // 
            this.lbl26.AutoSize = true;
            this.lbl26.Location = new System.Drawing.Point(514, 413);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(43, 17);
            this.lbl26.TabIndex = 40;
            this.lbl26.Text = "label1";
            this.lbl26.Visible = false;
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.Location = new System.Drawing.Point(514, 375);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(43, 17);
            this.lbl25.TabIndex = 39;
            this.lbl25.Text = "label1";
            this.lbl25.Visible = false;
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.Location = new System.Drawing.Point(514, 337);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(43, 17);
            this.lbl24.TabIndex = 38;
            this.lbl24.Text = "label1";
            this.lbl24.Visible = false;
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.Location = new System.Drawing.Point(514, 299);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(43, 17);
            this.lbl23.TabIndex = 37;
            this.lbl23.Text = "label1";
            this.lbl23.Visible = false;
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Location = new System.Drawing.Point(514, 261);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(43, 17);
            this.lbl22.TabIndex = 36;
            this.lbl22.Text = "label1";
            this.lbl22.Visible = false;
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.Location = new System.Drawing.Point(514, 223);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(43, 17);
            this.lbl21.TabIndex = 35;
            this.lbl21.Text = "label1";
            this.lbl21.Visible = false;
            // 
            // lbl20
            // 
            this.lbl20.AutoSize = true;
            this.lbl20.Location = new System.Drawing.Point(514, 185);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(43, 17);
            this.lbl20.TabIndex = 34;
            this.lbl20.Text = "label1";
            this.lbl20.Visible = false;
            // 
            // lbl19
            // 
            this.lbl19.AutoSize = true;
            this.lbl19.Location = new System.Drawing.Point(514, 147);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(43, 17);
            this.lbl19.TabIndex = 33;
            this.lbl19.Text = "label1";
            this.lbl19.Visible = false;
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Location = new System.Drawing.Point(514, 109);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(43, 17);
            this.lbl18.TabIndex = 32;
            this.lbl18.Text = "label1";
            this.lbl18.Visible = false;
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Location = new System.Drawing.Point(514, 71);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(43, 17);
            this.lbl17.TabIndex = 31;
            this.lbl17.Text = "label1";
            this.lbl17.Visible = false;
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Location = new System.Drawing.Point(514, 33);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(43, 17);
            this.lbl16.TabIndex = 30;
            this.lbl16.Text = "label1";
            this.lbl16.Visible = false;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(190, 562);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(277, 25);
            this.textBox15.TabIndex = 25;
            this.textBox15.Visible = false;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(190, 524);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(277, 25);
            this.textBox14.TabIndex = 24;
            this.textBox14.Visible = false;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(190, 486);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(277, 25);
            this.textBox13.TabIndex = 23;
            this.textBox13.Visible = false;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(190, 448);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(277, 25);
            this.textBox12.TabIndex = 22;
            this.textBox12.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(190, 410);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(277, 25);
            this.textBox11.TabIndex = 21;
            this.textBox11.Visible = false;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(190, 372);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(277, 25);
            this.textBox10.TabIndex = 20;
            this.textBox10.Visible = false;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(190, 334);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(277, 25);
            this.textBox9.TabIndex = 19;
            this.textBox9.Visible = false;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(190, 296);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(277, 25);
            this.textBox8.TabIndex = 18;
            this.textBox8.Visible = false;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(190, 258);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(277, 25);
            this.textBox7.TabIndex = 17;
            this.textBox7.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(190, 220);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(277, 25);
            this.textBox6.TabIndex = 16;
            this.textBox6.Visible = false;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(190, 182);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(277, 25);
            this.textBox5.TabIndex = 15;
            this.textBox5.Visible = false;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(190, 147);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(277, 25);
            this.textBox4.TabIndex = 14;
            this.textBox4.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(190, 106);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(277, 25);
            this.textBox3.TabIndex = 13;
            this.textBox3.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(190, 68);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(277, 25);
            this.textBox2.TabIndex = 12;
            this.textBox2.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(190, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(277, 25);
            this.textBox1.TabIndex = 11;
            this.textBox1.Visible = false;
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Location = new System.Drawing.Point(6, 565);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(43, 17);
            this.lbl15.TabIndex = 14;
            this.lbl15.Text = "label1";
            this.lbl15.Visible = false;
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Location = new System.Drawing.Point(6, 527);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(43, 17);
            this.lbl14.TabIndex = 13;
            this.lbl14.Text = "label1";
            this.lbl14.Visible = false;
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Location = new System.Drawing.Point(6, 489);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(43, 17);
            this.lbl13.TabIndex = 12;
            this.lbl13.Text = "label1";
            this.lbl13.Visible = false;
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Location = new System.Drawing.Point(6, 451);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(43, 17);
            this.lbl12.TabIndex = 11;
            this.lbl12.Text = "label1";
            this.lbl12.Visible = false;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Location = new System.Drawing.Point(6, 413);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(43, 17);
            this.lbl11.TabIndex = 10;
            this.lbl11.Text = "label1";
            this.lbl11.Visible = false;
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Location = new System.Drawing.Point(6, 375);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(43, 17);
            this.lbl10.TabIndex = 9;
            this.lbl10.Text = "label1";
            this.lbl10.Visible = false;
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Location = new System.Drawing.Point(6, 337);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(43, 17);
            this.lbl9.TabIndex = 8;
            this.lbl9.Text = "label1";
            this.lbl9.Visible = false;
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Location = new System.Drawing.Point(6, 299);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(43, 17);
            this.lbl8.TabIndex = 7;
            this.lbl8.Text = "label1";
            this.lbl8.Visible = false;
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Location = new System.Drawing.Point(6, 261);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(43, 17);
            this.lbl7.TabIndex = 6;
            this.lbl7.Text = "label1";
            this.lbl7.Visible = false;
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Location = new System.Drawing.Point(6, 223);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(43, 17);
            this.lbl6.TabIndex = 5;
            this.lbl6.Text = "label1";
            this.lbl6.Visible = false;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Location = new System.Drawing.Point(6, 185);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(43, 17);
            this.lbl5.TabIndex = 4;
            this.lbl5.Text = "label1";
            this.lbl5.Visible = false;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(6, 147);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(43, 17);
            this.lbl4.TabIndex = 3;
            this.lbl4.Text = "label1";
            this.lbl4.Visible = false;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(6, 109);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(43, 17);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "label1";
            this.lbl3.Visible = false;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(6, 71);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(43, 17);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "label1";
            this.lbl2.Visible = false;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(6, 33);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(43, 17);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "label1";
            this.lbl1.Visible = false;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(1207, 562);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(277, 25);
            this.textBox31.TabIndex = 90;
            this.textBox31.Visible = false;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(1207, 524);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(277, 25);
            this.textBox32.TabIndex = 89;
            this.textBox32.Visible = false;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(1207, 486);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(277, 25);
            this.textBox33.TabIndex = 88;
            this.textBox33.Visible = false;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(1207, 448);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(277, 25);
            this.textBox34.TabIndex = 87;
            this.textBox34.Visible = false;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(1207, 410);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(277, 25);
            this.textBox35.TabIndex = 86;
            this.textBox35.Visible = false;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(1207, 372);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(277, 25);
            this.textBox36.TabIndex = 85;
            this.textBox36.Visible = false;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(1207, 334);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(277, 25);
            this.textBox37.TabIndex = 84;
            this.textBox37.Visible = false;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(1207, 296);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(277, 25);
            this.textBox38.TabIndex = 83;
            this.textBox38.Visible = false;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(1207, 258);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(277, 25);
            this.textBox39.TabIndex = 82;
            this.textBox39.Visible = false;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(1207, 220);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(277, 25);
            this.textBox40.TabIndex = 81;
            this.textBox40.Visible = false;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(1207, 182);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(277, 25);
            this.textBox41.TabIndex = 80;
            this.textBox41.Visible = false;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(1207, 147);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(277, 25);
            this.textBox42.TabIndex = 79;
            this.textBox42.Visible = false;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(1207, 106);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(277, 25);
            this.textBox43.TabIndex = 78;
            this.textBox43.Visible = false;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(1207, 68);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(277, 25);
            this.textBox44.TabIndex = 77;
            this.textBox44.Visible = false;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(1207, 30);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(277, 25);
            this.textBox45.TabIndex = 76;
            this.textBox45.Visible = false;
            // 
            // lbl45
            // 
            this.lbl45.AutoSize = true;
            this.lbl45.Location = new System.Drawing.Point(1023, 565);
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(43, 17);
            this.lbl45.TabIndex = 75;
            this.lbl45.Text = "label1";
            this.lbl45.Visible = false;
            // 
            // lbl44
            // 
            this.lbl44.AutoSize = true;
            this.lbl44.Location = new System.Drawing.Point(1023, 527);
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(43, 17);
            this.lbl44.TabIndex = 74;
            this.lbl44.Text = "label1";
            this.lbl44.Visible = false;
            // 
            // lbl43
            // 
            this.lbl43.AutoSize = true;
            this.lbl43.Location = new System.Drawing.Point(1023, 489);
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(43, 17);
            this.lbl43.TabIndex = 73;
            this.lbl43.Text = "label1";
            this.lbl43.Visible = false;
            // 
            // lbl42
            // 
            this.lbl42.AutoSize = true;
            this.lbl42.Location = new System.Drawing.Point(1023, 451);
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(43, 17);
            this.lbl42.TabIndex = 72;
            this.lbl42.Text = "label1";
            this.lbl42.Visible = false;
            // 
            // lbl41
            // 
            this.lbl41.AutoSize = true;
            this.lbl41.Location = new System.Drawing.Point(1023, 413);
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(43, 17);
            this.lbl41.TabIndex = 71;
            this.lbl41.Text = "label1";
            this.lbl41.Visible = false;
            // 
            // lbl40
            // 
            this.lbl40.AutoSize = true;
            this.lbl40.Location = new System.Drawing.Point(1023, 375);
            this.lbl40.Name = "lbl40";
            this.lbl40.Size = new System.Drawing.Size(43, 17);
            this.lbl40.TabIndex = 70;
            this.lbl40.Text = "label1";
            this.lbl40.Visible = false;
            // 
            // lbl39
            // 
            this.lbl39.AutoSize = true;
            this.lbl39.Location = new System.Drawing.Point(1023, 337);
            this.lbl39.Name = "lbl39";
            this.lbl39.Size = new System.Drawing.Size(43, 17);
            this.lbl39.TabIndex = 69;
            this.lbl39.Text = "label1";
            this.lbl39.Visible = false;
            // 
            // lbl38
            // 
            this.lbl38.AutoSize = true;
            this.lbl38.Location = new System.Drawing.Point(1023, 299);
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(43, 17);
            this.lbl38.TabIndex = 68;
            this.lbl38.Text = "label1";
            this.lbl38.Visible = false;
            // 
            // lbl37
            // 
            this.lbl37.AutoSize = true;
            this.lbl37.Location = new System.Drawing.Point(1023, 261);
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(43, 17);
            this.lbl37.TabIndex = 67;
            this.lbl37.Text = "label1";
            this.lbl37.Visible = false;
            // 
            // lbl36
            // 
            this.lbl36.AutoSize = true;
            this.lbl36.Location = new System.Drawing.Point(1023, 223);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(43, 17);
            this.lbl36.TabIndex = 66;
            this.lbl36.Text = "label1";
            this.lbl36.Visible = false;
            // 
            // lbl35
            // 
            this.lbl35.AutoSize = true;
            this.lbl35.Location = new System.Drawing.Point(1023, 185);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(43, 17);
            this.lbl35.TabIndex = 65;
            this.lbl35.Text = "label1";
            this.lbl35.Visible = false;
            // 
            // lbl34
            // 
            this.lbl34.AutoSize = true;
            this.lbl34.Location = new System.Drawing.Point(1023, 147);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(43, 17);
            this.lbl34.TabIndex = 64;
            this.lbl34.Text = "label1";
            this.lbl34.Visible = false;
            // 
            // lbl33
            // 
            this.lbl33.AutoSize = true;
            this.lbl33.Location = new System.Drawing.Point(1023, 109);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(36, 17);
            this.lbl33.TabIndex = 63;
            this.lbl33.Text = "lbl33";
            this.lbl33.Visible = false;
            // 
            // lbl32
            // 
            this.lbl32.AutoSize = true;
            this.lbl32.Location = new System.Drawing.Point(1023, 71);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(36, 17);
            this.lbl32.TabIndex = 62;
            this.lbl32.Text = "lbl32";
            this.lbl32.Visible = false;
            // 
            // lbl31
            // 
            this.lbl31.AutoSize = true;
            this.lbl31.Location = new System.Drawing.Point(1023, 33);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(36, 17);
            this.lbl31.TabIndex = 61;
            this.lbl31.Text = "lbl31";
            this.lbl31.Visible = false;
            // 
            // btn_export
            // 
            this.btn_export.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_export.Location = new System.Drawing.Point(241, 15);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(137, 35);
            this.btn_export.TabIndex = 10;
            this.btn_export.Text = "Export";
            this.btn_export.UseVisualStyleBackColor = true;
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // grp_export
            // 
            this.grp_export.Controls.Add(this.label1);
            this.grp_export.Controls.Add(this.btn_export);
            this.grp_export.Location = new System.Drawing.Point(1074, 12);
            this.grp_export.Name = "grp_export";
            this.grp_export.Size = new System.Drawing.Size(432, 57);
            this.grp_export.TabIndex = 3;
            this.grp_export.TabStop = false;
            this.grp_export.Text = "Export";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Symbol", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Export to TXT if off screen:";
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1529, 721);
            this.Controls.Add(this.grp_export);
            this.Controls.Add(this.grp_info);
            this.Controls.Add(this.grp_select_hw);
            this.Enabled = false;
            this.Font = new System.Drawing.Font("Segoe UI Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frm_main";
            this.Text = "Chegger\'s System Info Checker";
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.grp_select_hw.ResumeLayout(false);
            this.grp_info.ResumeLayout(false);
            this.grp_info.PerformLayout();
            this.grp_export.ResumeLayout(false);
            this.grp_export.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_select_hw;
        private System.Windows.Forms.Button btn_motherboard;
        private System.Windows.Forms.Button btn_gpu;
        private System.Windows.Forms.Button btn_sdd;
        private System.Windows.Forms.Button btn_hdd;
        private System.Windows.Forms.Button btn_ram;
        private System.Windows.Forms.Button btn_cpu;
        private System.Windows.Forms.Button btn_netadapt;
        private System.Windows.Forms.Button btn_bios;
        private System.Windows.Forms.Button btn_monitor;
        private System.Windows.Forms.Button btn_os;
        private System.Windows.Forms.GroupBox grp_info;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label lbl45;
        private System.Windows.Forms.Label lbl44;
        private System.Windows.Forms.Label lbl43;
        private System.Windows.Forms.Label lbl42;
        private System.Windows.Forms.Label lbl41;
        private System.Windows.Forms.Label lbl40;
        private System.Windows.Forms.Label lbl39;
        private System.Windows.Forms.Label lbl38;
        private System.Windows.Forms.Label lbl37;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Button btn_export;
        private System.Windows.Forms.GroupBox grp_export;
        private System.Windows.Forms.Label label1;
    }
}

